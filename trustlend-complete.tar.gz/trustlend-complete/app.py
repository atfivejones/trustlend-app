#!/usr/bin/env python3
"""
TrustLend Application - Updated with Advanced Contract Creation
Main Flask application for loan management and contract creation
"""

import os
import sqlite3
import json
import hashlib
import secrets
import logging
from datetime import datetime, timedelta
from functools import wraps

from flask import (
    Flask, render_template, request, jsonify, redirect, url_for, 
    session, flash, abort, send_file, g
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['DATABASE'] = 'trustlend.db'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def get_db():
    """Get database connection"""
    if 'db' not in g:
        g.db = sqlite3.connect(app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(e=None):
    """Close database connection"""
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    """Initialize database with tables"""
    with app.app_context():
        db = get_db()
        with app.open_resource('py/schema.sql', mode='r') as f:
            db.executescript(f.read())
        db.commit()

@app.teardown_appcontext
def close_db_teardown(error):
    """Close database connection on teardown"""
    close_db()

def login_required(f):
    """Decorator to require login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('signin'))
        return f(*args, **kwargs)
    return decorated_function

def get_current_user():
    """Get current logged-in user"""
    if 'user_id' in session:
        db = get_db()
        user = db.execute(
            'SELECT * FROM users WHERE id = ?', (session['user_id'],)
        ).fetchone()
        return dict(user) if user else None
    return None

# Routes

@app.route('/')
def index():
    """Home page"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/signin')
def signin():
    """Sign in page"""
    return render_template('signin.html')

@app.route('/forgot-password')
def forgot_password():
    """Forgot password page"""
    return render_template('forgot-password.html')

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard"""
    user = get_current_user()
    db = get_db()
    
    # Get user's contracts
    contracts = db.execute('''
        SELECT * FROM contracts 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 10
    ''', (session['user_id'],)).fetchall()
    
    # Get statistics
    stats = {
        'total_contracts': db.execute(
            'SELECT COUNT(*) FROM contracts WHERE user_id = ?', 
            (session['user_id'],)
        ).fetchone()[0],
        'active_loans': db.execute(
            'SELECT COUNT(*) FROM contracts WHERE user_id = ? AND status = "active"', 
            (session['user_id'],)
        ).fetchone()[0],
        'total_amount': db.execute(
            'SELECT COALESCE(SUM(principal), 0) FROM contracts WHERE user_id = ?', 
            (session['user_id'],)
        ).fetchone()[0]
    }
    
    return render_template('dashboard.html', 
                         user=user, 
                         contracts=[dict(c) for c in contracts],
                         stats=stats)

@app.route('/create-note')
@login_required
def create_note():
    """Basic create promissory note page"""
    return render_template('create-note.html')

@app.route('/create-note-advanced')
@login_required
def create_note_advanced():
    """Advanced create promissory note page with 7-step workflow"""
    return render_template('create-note-advanced.html')

@app.route('/contracts')
@login_required
def contracts():
    """View all contracts"""
    db = get_db()
    user_contracts = db.execute('''
        SELECT * FROM contracts 
        WHERE user_id = ? 
        ORDER BY created_at DESC
    ''', (session['user_id'],)).fetchall()
    
    return render_template('contracts.html', 
                         contracts=[dict(c) for c in user_contracts])

@app.route('/contract-details/<int:contract_id>')
@login_required
def contract_details(contract_id):
    """View contract details"""
    db = get_db()
    contract = db.execute('''
        SELECT * FROM contracts 
        WHERE id = ? AND user_id = ?
    ''', (contract_id, session['user_id'])).fetchone()
    
    if not contract:
        abort(404)
    
    # Get payments for this contract
    payments = db.execute('''
        SELECT * FROM payments 
        WHERE contract_id = ? 
        ORDER BY due_date ASC
    ''', (contract_id,)).fetchall()
    
    return render_template('contract-details.html', 
                         contract=dict(contract),
                         payments=[dict(p) for p in payments])

@app.route('/billing')
@login_required
def billing():
    """Billing and subscription page"""
    user = get_current_user()
    return render_template('billing.html', user=user)

@app.route('/profile')
@login_required
def profile():
    """User profile page"""
    user = get_current_user()
    return render_template('profile.html', user=user)

@app.route('/support')
def support():
    """Support page"""
    return render_template('support.html')

@app.route('/audit-trail')
@login_required
def audit_trail():
    """Audit trail and verification page"""
    return render_template('audit-trail.html')

@app.route('/id-verification-simple')
@login_required
def id_verification():
    """Identity verification page"""
    return render_template('id-verification-simple.html')

@app.route('/sign-contract-flexible/<contract_id>')
@login_required
def sign_contract_flexible(contract_id):
    """Flexible contract signing page"""
    db = get_db()
    contract = db.execute('''
        SELECT * FROM contracts 
        WHERE id = ? AND user_id = ?
    ''', (contract_id, session['user_id'])).fetchone()
    
    if not contract:
        abort(404)
    
    return render_template('sign-contract-flexible.html', 
                         contract=dict(contract))

@app.route('/demand-letter-generator')
@login_required
def demand_letter_generator():
    """Demand letter generator page"""
    return render_template('demand-letter-generator.html')

# API Routes

@app.route('/api/auth/login', methods=['POST'])
def api_login():
    """API login endpoint"""
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    
    if not email or not password:
        return jsonify({'error': 'Email and password required'}), 400
    
    db = get_db()
    user = db.execute(
        'SELECT * FROM users WHERE email = ?', (email,)
    ).fetchone()
    
    if user and check_password_hash(user['password_hash'], password):
        session['user_id'] = user['id']
        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'email': user['email'],
                'name': user['full_name'],
                'plan': user['plan']
            },
            'token': 'mock-jwt-token'
        })
    
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/auth/register', methods=['POST'])
def api_register():
    """API registration endpoint"""
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('full_name')
    
    if not all([email, password, full_name]):
        return jsonify({'error': 'All fields required'}), 400
    
    db = get_db()
    
    # Check if user exists
    existing = db.execute(
        'SELECT id FROM users WHERE email = ?', (email,)
    ).fetchone()
    
    if existing:
        return jsonify({'error': 'Email already registered'}), 400
    
    # Create user
    password_hash = generate_password_hash(password)
    cursor = db.execute('''
        INSERT INTO users (email, password_hash, full_name, plan, created_at)
        VALUES (?, ?, ?, ?, ?)
    ''', (email, password_hash, full_name, 'basic', datetime.utcnow()))
    
    db.commit()
    user_id = cursor.lastrowid
    
    session['user_id'] = user_id
    
    return jsonify({
        'success': True,
        'user': {
            'id': user_id,
            'email': email,
            'name': full_name,
            'plan': 'basic'
        },
        'token': 'mock-jwt-token'
    })

@app.route('/api/contracts', methods=['GET', 'POST'])
@login_required
def api_contracts():
    """API contracts endpoint with enhanced validation"""
    db = get_db()
    
    if request.method == 'POST':
        data = request.get_json()
        
        # Enhanced validation for new contract creation
        required_fields = ['lenderFirstName', 'lenderLastName', 'lenderEmail', 
                          'borrowerFirstName', 'borrowerLastName', 'borrowerEmail', 'principal']
        
        missing_fields = [field for field in required_fields if not data.get(field)]
        if missing_fields:
            return jsonify({
                'error': f'Missing required fields: {", ".join(missing_fields)}'
            }), 400
        
        # Validate loan amount
        try:
            principal = float(data['principal'])
            if principal <= 0:
                return jsonify({'error': 'Principal amount must be greater than zero'}), 400
        except (ValueError, TypeError):
            return jsonify({'error': 'Invalid principal amount'}), 400
        
        # Validate interest rate if provided
        interest_rate = 0
        if data.get('interestRate'):
            try:
                interest_rate = float(data['interestRate'])
                if interest_rate < 0 or interest_rate > 30:
                    return jsonify({'error': 'Interest rate must be between 0% and 30%'}), 400
            except (ValueError, TypeError):
                return jsonify({'error': 'Invalid interest rate'}), 400
        
        # Validate age if DOB provided
        if data.get('borrowerDOB'):
            try:
                birth_date = datetime.strptime(data['borrowerDOB'], '%Y-%m-%d')
                today = datetime.now()
                age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
                if age < 18:
                    return jsonify({'error': 'Borrower must be 18 years or older'}), 400
            except ValueError:
                return jsonify({'error': 'Invalid date of birth format'}), 400
        
        # Create contract
        lender_name = f"{data['lenderFirstName']} {data['lenderLastName']}"
        borrower_name = f"{data['borrowerFirstName']} {data['borrowerLastName']}"
        
        cursor = db.execute('''
            INSERT INTO contracts (
                user_id, contract_type, lender_name, borrower_name, 
                principal, interest_rate, term_months, payment_frequency,
                contract_data, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            session['user_id'],
            data.get('noteType', 'simple'),
            lender_name,
            borrower_name,
            principal,
            interest_rate,
            data.get('termLength', 12),
            data.get('paymentFrequency', 'monthly'),
            json.dumps(data),
            'draft',
            datetime.utcnow()
        ))
        
        db.commit()
        contract_id = cursor.lastrowid
        
        # Create payment schedule if provided
        if data.get('paymentSchedule') and data['paymentSchedule'].get('schedule'):
            for payment in data['paymentSchedule']['schedule']:
                db.execute('''
                    INSERT INTO payments (
                        contract_id, due_date, amount, payment_type, status
                    ) VALUES (?, ?, ?, ?, ?)
                ''', (
                    contract_id,
                    payment.get('dueDate'),
                    payment.get('paymentAmount', 0),
                    'regular',
                    'pending'
                ))
            db.commit()
        
        return jsonify({
            'success': True,
            'contract': {
                'id': contract_id,
                'lender_name': lender_name,
                'borrower_name': borrower_name,
                'principal': principal,
                'status': 'draft'
            }
        })
    
    else:
        # Get contracts
        contracts = db.execute('''
            SELECT * FROM contracts 
            WHERE user_id = ? 
            ORDER BY created_at DESC
        ''', (session['user_id'],)).fetchall()
        
        return jsonify({
            'contracts': [dict(contract) for contract in contracts]
        })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    """404 error handler"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """500 error handler"""
    logger.error(f"Internal error: {error}")
    return render_template('500.html'), 500

# CLI commands
@app.cli.command()
def init_database():
    """Initialize the database"""
    init_db()
    print("Database initialized successfully!")

@app.cli.command()
def create_admin():
    """Create admin user"""
    email = input("Admin email: ")
    password = input("Admin password: ")
    full_name = input("Full name: ")
    
    db = get_db()
    password_hash = generate_password_hash(password)
    
    try:
        db.execute('''
            INSERT INTO users (email, password_hash, full_name, plan, created_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (email, password_hash, full_name, 'premium', datetime.utcnow()))
        db.commit()
        print(f"Admin user {email} created successfully!")
    except sqlite3.IntegrityError:
        print(f"User {email} already exists!")

if __name__ == '__main__':
    # Create database tables if they don't exist
    if not os.path.exists(app.config['DATABASE']):
        with app.app_context():
            init_db()
            print("Database created and initialized!")
    
    # Run the app
    debug_mode = os.environ.get('FLASK_ENV') == 'development'
    app.run(host='0.0.0.0', port=5000, debug=debug_mode)
